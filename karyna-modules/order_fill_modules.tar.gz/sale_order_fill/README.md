# Fill Sale Order - OpenERP Module
##Author: _Carlos Llamacho_
### Version: 1.0
###Description:
Allows to fill a sale order with all products that can be sold from a set of
categories, or none to use all saleable products.
### Category: _Sales_
###Depends:
1. base
2. sale 
