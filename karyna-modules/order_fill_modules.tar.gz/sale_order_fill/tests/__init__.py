import test_sale_fill

fast_suite = [test_sale_fill]