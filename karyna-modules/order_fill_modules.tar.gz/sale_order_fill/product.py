#-*- coding: utf-8 -*-
from openerp.osv import orm, fields
